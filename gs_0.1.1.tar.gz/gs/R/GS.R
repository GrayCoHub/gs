gs <- function(x) {
  msg <- print("", quote = FALSE)
  msg <- print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", quote = FALSE, max.levels = 0)
  msg2 <- print((x), quote = FALSE )
  print("", quote = FALSE)

  # strsplit(msg, "\n")[[1]]     # unused

  # https://github.com/GraySmith80/R_Library_Print_Divider
}
